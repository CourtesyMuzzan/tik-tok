// Função para obter os parâmetros da URL
function getUrlParams() {
    let params = {};
    let queryString = window.location.search.substring(1);
    let queryArray = queryString.split("&");

    queryArray.forEach(function(param) {
        let [key, value] = param.split("=");
        params[key] = decodeURIComponent(value);
    });

    return params;
}

// Função para armazenar os parâmetros no localStorage
function storeParamsInLocalStorage(params) {
    for (let key in params) {
        if (params.hasOwnProperty(key)) {
            localStorage.setItem(key, params[key]);
        }
    }

    // Se todos os parâmetros necessários estiverem presentes, gerar o utm_term
    if (params.pixel_id && params.click_id && params.CampaignID && params.CreativeID && params.adSETID) {
        // Pega domínio e slug
        const domain = window.location.hostname;
        const slug = window.location.pathname;
        
        // Cria o utm_term com domínio e slug no final
        const utm_term = `${params.pixel_id}|${params.click_id}|${params.CampaignID}|${params.CreativeID}|${params.adSETID}|${domain}${slug}`;
        
        localStorage.setItem('utm_term', utm_term);
    }
}

// Executar as funções
let params = getUrlParams();
storeParamsInLocalStorage(params);

// Função para adicionar parâmetros ao href
function addParamsToLinks() {
    // Obter todos os parâmetros armazenados no localStorage
    let params = {
        CampaignID: localStorage.getItem('CampaignID'),
        adSETID: localStorage.getItem('adSETID'),
        CreativeID: localStorage.getItem('CreativeID'),
        click_id: localStorage.getItem('click_id'),
        pixel_id: localStorage.getItem('pixel_id'),
        utm_campaign: localStorage.getItem('utm_campaign'),
        utm_medium: localStorage.getItem('utm_medium'),
        utm_content: localStorage.getItem('utm_content'),
        utm_source: localStorage.getItem('utm_source'),
        utm_term: localStorage.getItem('utm_term') // Adicionando o utm_term
    };

    // Filtrar apenas os parâmetros não nulos
    let filteredParams = {};
    for (let key in params) {
        if (params[key] !== null && params[key] !== 'null' && params[key] !== undefined) {
            filteredParams[key] = params[key];
        }
    }

    // Converter o objeto de parâmetros em uma string de consulta (query string)
    let queryString = Object.keys(filteredParams).map(key => `${key}=${encodeURIComponent(filteredParams[key])}`).join('&');

    // Obter todos os links da página
    let links = document.querySelectorAll('a[href]');

    // Adicionar a string de consulta a cada link
    links.forEach(link => {
        let url = new URL(link.href);
        if (queryString) {
            url.search += (url.search ? '&' : '') + queryString;
        }
        link.href = url.toString();
    });
}

// Executar a função quando a página carregar
document.addEventListener('DOMContentLoaded', addParamsToLinks);


function redirecionar(baseUrl) {
    // Obter todos os parâmetros armazenados no localStorage
    let params = {
        CampaignID: localStorage.getItem('CampaignID'),
        adSETID: localStorage.getItem('adSETID'),
        CreativeID: localStorage.getItem('CreativeID'),
        click_id: localStorage.getItem('click_id'),
        pixel_id: localStorage.getItem('pixel_id'),
        utm_campaign: localStorage.getItem('utm_campaign'),
        utm_medium: localStorage.getItem('utm_medium'),
        utm_content: localStorage.getItem('utm_content'),
        utm_source: localStorage.getItem('utm_source'),
        utm_term: localStorage.getItem('utm_term')
    };

    // Filtrar valores nulos
    let filteredParams = {};
    for (let key in params) {
        if (params[key] !== null && params[key] !== 'null' && params[key] !== undefined) {
            filteredParams[key] = params[key];
        }
    }

    // Converter o objeto de parâmetros em uma string de consulta (query string)
    let queryString = Object.keys(filteredParams)
        .map(key => `${key}=${encodeURIComponent(filteredParams[key])}`)
        .join('&');

    // Construir a URL completa
    let url = baseUrl + (baseUrl.includes('?') ? '&' : '?') + queryString;

    // Redirecionar para a URL
    window.location.href = url;
}